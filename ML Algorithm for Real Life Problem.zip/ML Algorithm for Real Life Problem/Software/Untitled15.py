#!/usr/bin/env python
# coding: utf-8

# # importing packages

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


# # importing dataset 

# In[2]:


dataset=pd.read_csv("heart.csv")
dataset


# # checking null value

# In[3]:


dataset.isna().sum()


# # checking aqvailable data types

# In[4]:


dataset.info()


# # changing string values to integers

# In[5]:


from sklearn.preprocessing import LabelEncoder
label = LabelEncoder()


# In[6]:


dataset["Sex"]=label.fit_transform(dataset["Sex"])
dataset["ChestPainType"]=label.fit_transform(dataset["ChestPainType"])
dataset["RestingECG"]=label.fit_transform(dataset["RestingECG"])
dataset["ExerciseAngina"]=label.fit_transform(dataset["ExerciseAngina"])
dataset["ST_Slope"]=label.fit_transform(dataset["ST_Slope"])


# In[7]:


dataset


# In[8]:


dataset.info()


# # setting up dependable and independent variables

# In[9]:


x=dataset[["Age", "ChestPainType","RestingBP","Cholesterol","FastingBS","RestingECG","MaxHR","ST_Slope"]]
y=dataset["HeartDisease"]


# # splitting up data for training and testing

# In[10]:


from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.25)


# # gaussian process classifier

# In[11]:


from sklearn.gaussian_process import GaussianProcessClassifier

gpc = GaussianProcessClassifier()


# # getting the value of the model

# In[12]:


gpc.fit(X_train, y_train)
y_pred= gpc.predict(X_test)
y_pred


# # finding accuracy 

# In[13]:


print(gpc.score(X_train,y_train))
print(gpc.score(X_test,y_test))


# # gaussian process regression

# In[14]:


from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import WhiteKernel, DotProduct, RBF


# In[15]:


kernel = RBF() + WhiteKernel()
gpr = GaussianProcessRegressor(kernel=kernel, random_state=20)


# # fitting the values in x and y

# In[16]:


gpr.fit(X_train, y_train)


# # getting the value of the model

# In[17]:


y_pred1= gpr.predict(X_test)
y_pred1


# # getting the accuracy

# In[18]:


print(gpr.score(X_train,y_train))
print(gpr.score(X_test,y_test))

