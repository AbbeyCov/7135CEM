
function out = genetic_algorithm(sl,pms)




for it = 1:length(sl)
    if sl(it) < pms(1)
        val(it) = 1.25;
    elseif sl(it) < pms(2)
        val(it) = 2.5;
    elseif sl(it) < pms(3)
        val(it) = 5;
    elseif sl(it) < pms(4)
        val(it) = 7.5;
    elseif sl(it) < pms(5)
        val(it) = 10; 
    else
        val(it) = 0;
    end
end

out = 0.1*val'; 

end